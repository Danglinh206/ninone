module.exports = {
	Bite: require('./Bite.ability'),
	Investigator: require('./Investigator.ability'),
	Kill: require('./Kill.ability'),
	Pair: require('./Pair.ability'),
	Protect: require('./Protect.ability'),
	RoleReveal: require('./RoleReveal.ability'),
	Seer: require('./Seer.ability'),
	VoteLynch: require('./VoteLynch.ability')
};

//bannananan