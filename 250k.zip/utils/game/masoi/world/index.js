module.exports = {
	Normal: require('./Normal')
};

//babnan